
import java.util.ArrayList;
import java.util.Scanner;

public class Ohjelma {

    public static void main(String[] args) {
        // täällä ei tarvitse tehdä mitään..
    }
}
